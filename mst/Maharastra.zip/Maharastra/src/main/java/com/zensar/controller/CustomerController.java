package com.zensar.controller;

import com.zensar.service.CustomerService;

public class CustomerController {
	
	private CustomerService customerService;
	
	/*
	 * public checkLogin(HttpServletRequest request,HttpServletResponse
	 * response) {
	 * 
	 * 
	 * }
	 */

}
